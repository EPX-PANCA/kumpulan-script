## Postgres Exporter - Node Exporter - Prometheus - Grafana (Docker Compose)

```sh
Prerequisite :
- Postgres 13
- Docker

Tested On : 
- Centos 7
- Postgres 13
- Docker 20.10.7
- Docker Compose 1.29.2

Jalankan script setup.sh di root mode.

Import linux (nodenya) metrics -> dashboard URL ID : 1860
Import Postgres Exporter metrics -> dashboard URL ID : 9628
```